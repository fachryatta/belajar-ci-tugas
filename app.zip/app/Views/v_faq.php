<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Halaman FAQ
<?= $this->endSection() ?>
