<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Halaman Keranjang
<?= $this->endSection() ?>
